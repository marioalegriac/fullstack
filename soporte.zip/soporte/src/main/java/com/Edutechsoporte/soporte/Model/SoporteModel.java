package com.Edutechsoporte.soporte.Model;

import jakarta.persistence.*;
import lombok.*;
import java.util.Date;

@Entity
@Table(name = "soportes")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SoporteModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(unique=true, length = 13, nullable=false)
    public String run;

    @Column(nullable = false)
    public String nombre;

    @Column(nullable = false)
    public String apellido;

    @Column(nullable = false)
    public String correo;

    @Column(nullable = true)
    public Date fechaNacimiento;

}
