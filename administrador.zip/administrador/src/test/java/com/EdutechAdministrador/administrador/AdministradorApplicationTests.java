package com.EdutechAdministrador.administrador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdministradorApplicationTests {

	@Test
	void contextLoads() {
	}

}
