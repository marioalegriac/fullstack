package com.EdutechAdministrador.administrador.Dto;

import lombok.Data;
import java.util.Date;


@Data
public class ClienteDTO {

    public Integer id;
    public String run;
    public String nombre;
    public String apellido;
    public Date fechaNacimiento;
    public String correo;

}
