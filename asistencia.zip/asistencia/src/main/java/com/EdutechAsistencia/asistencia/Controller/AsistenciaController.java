package com.EdutechAsistencia.asistencia.Controller;

import com.EdutechAsistencia.asistencia.Model.AsistenciaModel;
import com.EdutechAsistencia.asistencia.Service.AsistenciaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


// http://localhost:8084/api/v1/asistencia url para postman

@RestController
@RequestMapping("/api/v1/asistencia")
public class AsistenciaController {

    @Autowired
    public AsistenciaService asistenciaService;

    @GetMapping
    public ResponseEntity<List<AsistenciaModel>> listar(){
        List<AsistenciaModel> lista = asistenciaService.findall();
        if(lista.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(lista);
    }
    

    @PostMapping
    public ResponseEntity<AsistenciaModel> guardar(@RequestBody AsistenciaModel asistencia) {
        AsistenciaModel nueva = asistenciaService.save(asistencia);
        return ResponseEntity.status(201).body(nueva);
    }

    @GetMapping("/{id}")
    public ResponseEntity<AsistenciaModel> buscar(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(asistenciaService.findById(id));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }


    @PutMapping("/{id}")
    public ResponseEntity<AsistenciaModel> actualizar(@PathVariable Long id, @RequestBody AsistenciaModel asistencia) {
        try {
            AsistenciaModel existente = asistenciaService.findById(id);
            existente.setRun(asistencia.getRun());
            existente.setNombre(asistencia.getNombre());
            existente.setApellido(asistencia.getApellido());
            existente.setFechaAsistencia(asistencia.getFechaAsistencia());
            existente.setVecesAsistido(asistencia.getVecesAsistido());

            return ResponseEntity.ok(asistenciaService.save(existente));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Long id) {
        try {
            asistenciaService.delete(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
  


}
