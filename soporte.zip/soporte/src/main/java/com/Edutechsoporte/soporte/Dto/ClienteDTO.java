package com.Edutechsoporte.soporte.Dto;

import lombok.Data;

@Data
public class ClienteDTO {

    public String nombre;
    public String apellido;
    public String correo;

}
