package com.curso.cl.curso.controller;

import com.curso.cl.curso.model.CursoModel;
import com.curso.cl.curso.service.CursoService;
import com.curso.cl.curso.repository.CursoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;



// url postman http://localhost:8081/api/v1/cursos


@RestController
@RequestMapping("/api/v1/cursos")
public class CursoController {

    @Autowired
    public CursoService cursoService;


    @GetMapping
    public List<CursoModel> obtenerTodosLosCursos(){
        return cursoService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<CursoModel> buscar (@PathVariable Long id){
        return cursoService.findById(id)
            .map(curso -> ResponseEntity.ok(curso))
            .orElseGet(()-> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<CursoModel> crear (@RequestBody CursoModel curso){
        CursoModel cursoNuevo = cursoService.save(curso);
        return ResponseEntity.status(201).body(cursoNuevo);
    }


    @PutMapping("/{id}")
    public ResponseEntity<CursoModel> actualizar (@PathVariable Long id, @RequestBody CursoModel curso){
        return cursoService.findById(id)
            .map(existingCurso -> {
                existingCurso.setNombre(curso.getNombre());
                existingCurso.setDescripcion(curso.getDescripcion());
                existingCurso.setDuracionHoras(curso.getDuracionHoras());
                cursoService.save(existingCurso);
                return ResponseEntity.ok(existingCurso);
            })
            .orElseGet(() -> ResponseEntity.notFound().build());

    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar (@PathVariable Long id){
        if(cursoService.findById(id).isPresent()){
            cursoService.delete(id);
            return ResponseEntity.noContent().build();
        }else {
            return ResponseEntity.notFound().build();
        }
    }


    @DeleteMapping("/{cursoId}/clientes/{clienteId}")
    public ResponseEntity<String> eliminarClienteDeCurso(
        @PathVariable Long cursoId,
        @PathVariable Long clienteId){
            boolean eliminado = cursoService.eliminarClienteDeCurso(cursoId, clienteId);
            if(!eliminado){
                return ResponseEntity.notFound().build();
            } 
            return ResponseEntity.noContent().build();
        }
    


    @PostMapping("/{cursoId}/clientes/{clienteId}")
    public ResponseEntity<String> agregarClienteACurso(
        @PathVariable Long cursoId,
        @PathVariable Long clienteId) {
            boolean agregado = cursoService.agregarClienteACurso(cursoId, clienteId);
            if(!agregado){
                return ResponseEntity.notFound().build();
            }
            return ResponseEntity.ok("Cliente agregado con exito");
        }
    
    




}


    
    
    
    
    


