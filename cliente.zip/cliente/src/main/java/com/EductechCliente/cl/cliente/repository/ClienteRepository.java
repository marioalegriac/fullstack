package com.EductechCliente.cl.cliente.repository;

import com.EductechCliente.cl.cliente.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {

    @Query("SELECT c FROM Cliente c Where c.apellido=: apellido")
    List <Cliente> buscarPorApellido(@Param("apellido")String apellido);

    @Query(value = "SELECT * FROM Cliente WHERE correo=:correo",nativeQuery = true)
    Cliente buscarPorlCorreo(@Param("correo")String correo);

}
