package com.Edutechsoporte.soporte.Service;

import com.Edutechsoporte.soporte.Model.SoporteModel;
import com.Edutechsoporte.soporte.Repository.SoporteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class SoporteService {

    @Autowired
    public SoporteRepository soporteRepository;

    public SoporteModel guardar(SoporteModel soporte){
        return soporteRepository.save(soporte);
    }

    public Optional<SoporteModel> obtenerPorId(Long id){
        return soporteRepository.findById(id);
    }

    

}
