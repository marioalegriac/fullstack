package com.EdutechAdministrador.administrador.Model;

import java.util.Date;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.*;



@Entity
@Table(name = "administradores")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AdministradorModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    @Column(unique=true, length = 13, nullable=false)
    public String run;

    @Column(nullable = false)
    public String nombre;

    @Column(nullable = false)
    public String apellido;

    @Column(nullable = true)
    public Date fechaNacimiento;

    @Column(nullable = false)
    public String correo;

    @Column(nullable = false)
    @Size(min = 5, message = "La contraseña debe tener minimo 5 caracteres" )
    public String password;
    

}
