package com.Edutechsoporte.soporte.Repository;

import com.Edutechsoporte.soporte.Model.SoporteModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SoporteRepository extends JpaRepository<SoporteModel, Long> {

}
