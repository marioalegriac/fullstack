package com.EdutechAdministrador.administrador.Controller;

import com.EdutechAdministrador.administrador.Dto.ClienteDTO;
import com.EdutechAdministrador.administrador.Dto.CursoDTO;
import com.EdutechAdministrador.administrador.Model.AdministradorModel;
import com.EdutechAdministrador.administrador.Service.AdministradorService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


// url postman http://localhost:8082/api/v2/administradores

@RestController
@RequestMapping("/api/v2/administradores")
public class AdministradorController {

    public final AdministradorService service;

    @Autowired
    public AdministradorService administradorService;

    public AdministradorController(AdministradorService service){
        this.service = service;
    }

    @GetMapping
    public List<AdministradorModel> listar(){
        return service.obtenerTodos();
    }

    @GetMapping("/{id}")
    public ResponseEntity<AdministradorModel> obtenerPorId(@PathVariable Long id){
        return service.obtenerPorId(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void>eliminar(@PathVariable Long id){
        service.eliminar(id);
        return ResponseEntity.noContent().build();
    }


    @GetMapping("/cursos/{cursoId}/clientes")
    public ResponseEntity<List<ClienteDTO>> obtenerClienteDeCurso(@PathVariable Long cursoId){
        List<ClienteDTO> clientes = service.obtenerClientesDeCurso(cursoId);
        return ResponseEntity.ok(clientes);
    }

    @GetMapping("/clientes/{clienteId}/cursos")
    public ResponseEntity<List<CursoDTO>> obtenerCursosDelCliente(@PathVariable Long clienteId){
        List<CursoDTO> cursos = service.obtenerCursosDelCliente(clienteId);
        return ResponseEntity.ok(cursos);
    }

    @PostMapping
    public ResponseEntity<AdministradorModel> crearAdministrador(@RequestBody AdministradorModel administrador){
        AdministradorModel nuevoAdmin = administradorService.guardar(administrador);
        return new ResponseEntity<>(nuevoAdmin, HttpStatus.CREATED);
    }

    @DeleteMapping("/cursos/{cursoId}/clientes/{clienteId}")
    public ResponseEntity<Void> eliminarClienteDeCurso(@PathVariable Long cursoId, @PathVariable Long clienteId ){
        boolean eliminado = service.eliminarClienteDeCurso(cursoId, clienteId);
        if(eliminado){
            return ResponseEntity.noContent().build();
        }else{
            return ResponseEntity.notFound().build();
        }
    }


    @PutMapping("/{id}")
    public ResponseEntity<AdministradorModel> actualizar(@PathVariable Long id, @RequestBody AdministradorModel adminActualizado){
        return administradorService.obtenerPorId(id)
            .map(adminExistente -> {
                adminExistente.setNombre(adminActualizado.getNombre());
                adminExistente.setApellido(adminActualizado.getApellido());
                adminExistente.setPassword(adminActualizado.getPassword());
                adminExistente.setCorreo(adminActualizado.getCorreo());
                AdministradorModel actualizado = administradorService.guardar(adminExistente);
                return ResponseEntity.ok(actualizado);
            })
            .orElseGet(() -> ResponseEntity.notFound().build());
        
    }

        
}
