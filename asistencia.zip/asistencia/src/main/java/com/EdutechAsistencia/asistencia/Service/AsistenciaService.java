package com.EdutechAsistencia.asistencia.Service;

import com.EdutechAsistencia.asistencia.Model.AsistenciaModel;
import com.EdutechAsistencia.asistencia.Repository.AsistenciaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AsistenciaService {

    @Autowired
    public AsistenciaRepository asistenciaRepository;

    public List<AsistenciaModel> findall(){
        return asistenciaRepository.findAll();
    }

    public AsistenciaModel findById(Long id){
        return asistenciaRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("ID ingresada no encontrada"));
    }

    public AsistenciaModel save(AsistenciaModel asistencia){
        return asistenciaRepository.save(asistencia);
    }

    public void delete(Long id){
        asistenciaRepository.deleteById(id);
    }

}

