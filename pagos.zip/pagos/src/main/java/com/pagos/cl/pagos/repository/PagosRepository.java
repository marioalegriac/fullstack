package com.pagos.cl.pagos.repository;

import com.pagos.cl.pagos.model.Pagos;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface PagosRepository extends JpaRepository<Pagos, Integer> {
    
    @Query("SELECT p FROM Pagos p WHERE p.monto > :monto")
    List<Pagos> findByMontoGreaterThan(@Param("monto") Double monto);


    @Query("SELECT p FROM Pagos p WHERE p.descripcion LIKE %:descripcion%")
    List<Pagos> findByDescripcion(@Param("descripcion") String descripcion);

    @Query("SELECT p FROM Pagos p WHERE p.fechapago = :fechapago")
    List<Pagos> findByFechaPago(@Param("fechapago") Date fechapago);

    @Query("SELECT p FROM Pagos p WHERE p.metodoPago = :metodoPago")
    List<Pagos> findByMetodoPago(@Param("metodoPago") String metodoPago);
}