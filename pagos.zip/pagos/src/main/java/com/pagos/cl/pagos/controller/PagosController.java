package com.pagos.cl.pagos.controller;

import com.pagos.cl.pagos.model.Pagos;
import com.pagos.cl.pagos.service.PagosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


// url postman http://localhost:8085/api/v1/pagos


@RestController
@RequestMapping("/api/v1/pagos")
public class PagosController {

    @Autowired
    private PagosService pagosService;

    @GetMapping
    public ResponseEntity<List<Pagos>> listar() {
        List<Pagos> pagos = pagosService.findAll();
        if (pagos.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(pagos);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Pagos> buscar(@PathVariable Integer id) {
        try {
            Pagos pagos = pagosService.findById(id);
            return ResponseEntity.ok(pagos);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Pagos> guardar(@RequestBody Pagos pagos) {
        Pagos nuevoPago = pagosService.save(pagos);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevoPago);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Pagos> actualizar(@PathVariable Integer id, @RequestBody Pagos pagos) {
        try {
            Pagos pagoExistente = pagosService.findById(id);
            pagoExistente.setMonto(pagos.getMonto());
            pagoExistente.setFechapago(pagos.getFechapago());
            pagoExistente.setMetodoPago(pagos.getMetodoPago());
            pagoExistente.setDescripcion(pagos.getDescripcion());

            pagosService.save(pagoExistente);
            return ResponseEntity.ok(pagoExistente);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        try {
            pagosService.delete(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}