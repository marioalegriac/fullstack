package com.curso.cl.curso.service;

import com.curso.cl.curso.model.CursoModel;
import com.curso.cl.curso.repository.CursoRepository;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;
import java.util.Optional;


@Service
@Transactional
public class CursoService {

    @Autowired
    public CursoRepository cursoRepository;

    public List<CursoModel> findAll(){
        return cursoRepository.findAll();
    }

    public Optional<CursoModel> findById(Long id){
        return cursoRepository.findById(id);
    }

    public CursoModel save (CursoModel curso){
        return cursoRepository.save(curso);
    }

    public void delete(Long id){
        cursoRepository.deleteById(id);
    }


    public boolean eliminarClienteDeCurso(Long cursoId, Long clienteId){
        Optional<CursoModel> cursoOpt = cursoRepository.findById(cursoId);
        if(cursoOpt.isPresent()){
            CursoModel curso = cursoOpt.get();
            if(curso.getClienteIds() != null && curso.getClienteIds().contains(clienteId)){
                curso.getClienteIds().remove(clienteId);
                cursoRepository.save(curso);
                return true;
            }
        }
        return false;
    }


    public boolean agregarClienteACurso(Long cursoId, Long clienteId){
        Optional<CursoModel> cursoOpt = cursoRepository.findById(cursoId);
        if(cursoOpt.isEmpty()){
            return false;
        }
        CursoModel curso = cursoOpt.get();
        if(!curso.getClienteIds().contains(clienteId)){
            curso.getClienteIds().add(clienteId);
            cursoRepository.save(curso);
        }
        return true;
    }
    


}
