package com.Edutechsoporte.soporte.Controller;

import com.Edutechsoporte.soporte.Dto.ClienteDTO;
import com.Edutechsoporte.soporte.Model.SoporteModel;
import com.Edutechsoporte.soporte.Repository.SoporteRepository;
import com.Edutechsoporte.soporte.Service.SoporteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Optional;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;


// url postman http://localhost:8083/api/v1/soportes


@RestController
@RequestMapping("/api/v1/soportes")
public class SoporteController {

    @Autowired
    public SoporteService soporteService;
    
    @Autowired
    public SoporteRepository soporteRepository;

    @PostMapping
    public ResponseEntity<SoporteModel> crear (@RequestBody SoporteModel soporte){
        return ResponseEntity.ok(soporteService.guardar(soporte));
    }

    @GetMapping
    public ResponseEntity<List<SoporteModel>> listar(){
        List<SoporteModel> listaSoportes = soporteRepository.findAll();

        if(listaSoportes.isEmpty()){
            return ResponseEntity.noContent().build();
        }else{
            return ResponseEntity.ok(listaSoportes);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<SoporteModel> obtener(@PathVariable Long id){
        return soporteService.obtenerPorId(id)
            .map(soporte -> ResponseEntity.ok(soporte))
            .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<SoporteModel> actualizarSoporte(@PathVariable Long id, @RequestBody SoporteModel soporteActualizado){
        Optional<SoporteModel> soporteExistente = soporteRepository.findById(id);

        if(soporteExistente.isPresent()){
            SoporteModel soporte = soporteExistente.get();
            soporte.setNombre(soporteActualizado.getNombre());
            soporte.setApellido(soporteActualizado.getApellido());
            soporte.setCorreo(soporteActualizado.getCorreo());
            soporteRepository.save(soporte);
            return ResponseEntity.ok(soporte);
        }else {
            return ResponseEntity.notFound().build();
        }

    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarSoporte(@PathVariable Long id){
        if(soporteRepository.existsById(id)){
            soporteRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }else{
            return ResponseEntity.notFound().build();
        }
    }


    @GetMapping("/cliente/{clienteId}")
    public ResponseEntity<ClienteDTO> obtenerCliente(@PathVariable Integer clienteId){
        String url = "http://localhost:8080/api/v1/clientes/" + clienteId;
        RestTemplate restTemplate = new RestTemplate();

        try {
            ClienteDTO cliente = restTemplate.getForObject(url, ClienteDTO.class);
            return ResponseEntity.ok(cliente);
        } catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

}
